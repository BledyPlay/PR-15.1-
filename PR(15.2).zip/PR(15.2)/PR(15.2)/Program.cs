﻿using System;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        string timeRegex = @"^(0[0-9]|1[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$";
        string ipRegex = @"^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$";
        string siteRegex = @"^(https?|ftp)://[^\s/$.?#].[^\s]*$";

        string inputTime = "12:34:56";
        string inputIP = "192.168.0.1";
        string inputSite = "http://www.edldlld.com";

        bool isTimeValid = Regex.IsMatch(inputTime, timeRegex);
        bool isIPValid = Regex.IsMatch(inputIP, ipRegex);
        bool isSiteValid = Regex.IsMatch(inputSite, siteRegex);

        Console.WriteLine("Время указано верно: " + isTimeValid);
        Console.WriteLine("IP адрес указан верно: " + isIPValid);
        Console.WriteLine("Адрес сайта указан верно: " + isSiteValid);
    }
}