﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Введите сообщение:");
        string message = Console.ReadLine();

        int vowelCount = 0;
        int letterCount = 0;

        foreach (char c in message)
        {
            if (IsVowel(c))
            {
                vowelCount++;
            }

            if (Char.IsLetter(c))
            {
                letterCount++;
            }
        }

        double vowelPercentage = (double)vowelCount / letterCount * 100;
        Console.WriteLine($"Процент гласных букв: {vowelPercentage:F2}%");

        Console.WriteLine("Введите слово для поиска:");
        string word = Console.ReadLine();

        if (message.Contains(word, StringComparison.OrdinalIgnoreCase))
        {
            Console.WriteLine($"Слово \"{word}\" найдено в сообщении.");
        }
        else
        {
            Console.WriteLine($"Слово \"{word}\" не найдено в сообщении.");
        }
    }

    static bool IsVowel(char c)
    {
        switch (Char.ToLower(c))
        {
            case 'a':
            case 'e':
            case 'i':
            case 'o':
            case 'u':
            case 'y':
                return true;
            default:
                return false;
        }
    }
}
